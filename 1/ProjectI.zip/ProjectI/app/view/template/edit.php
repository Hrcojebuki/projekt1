<div class="d-md-flex fill align-items-center justify-content-center py-5">
    <?php if(isset($data["path"])) require $data["path"]; ?>
</div>