<div class="d-flex fill align-items-center justify-content-center"> 
    <div class=" min-w-400">
        <div class="container">
            <div class="row">
                <div class="col">
                    <h1>It looks like you are lost..</h1>
                    <p>Page you are looking for does not exist</p>
                </div>
                <div class="col text-center">
                    <img class="mb-4 circle" height="200" src="public/img/sad.png" alt="Avatar">
                </div>
            </div>
        </div>
    </div>
</div>